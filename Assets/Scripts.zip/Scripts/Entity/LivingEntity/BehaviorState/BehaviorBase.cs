using UnityEngine;
using System;
using System.Collections.Generic;
public class BehaviorBase
{
    protected MonsterEntity myEntity;
    

    public virtual void Act()
    {

    }
}
