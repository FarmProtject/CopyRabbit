using UnityEngine;
using System;
using System.Collections.Generic;
public class PlayerState_Auto 
{
    Vector2 moveDir;

    public Vector2 GetMoveDirection()
    {
        return moveDir;
    }
}
