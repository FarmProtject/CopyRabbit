using UnityEngine;
using System;
using System.Collections.Generic;

public class EntityStats
{
    int id;
    string name;
    double attack;
    double defence;
    double healthPoint;
    int moveSpeed;
}
