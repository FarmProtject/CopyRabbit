using UnityEngine;
using System;
using System.Collections.Generic;
public class StageField : MonoBehaviour
{
    StageData myData;
    bool isPlayerOn = false;
    void OnStart()
    {
        isPlayerOn = false;
        Add_To_List();
    }


    public void Add_To_List()
    {
        if(isPlayerOn == false)
        {
            GameManager._instance.Add_To_Stage_List(this);
        }
    }

    public void Change_isPlayerOn(bool isOn)
    {
        isPlayerOn = isOn;
    }



    public int Gen_Monster(int monsterCount)
    {
        int maxCount = GameManager._instance.Get_Once_Stage_MaxGenCount(); //��û �� ���� �� 
        int genCount = Mathf.Clamp(monsterCount, 0, maxCount); //������ ���� ��
        int rest = monsterCount - genCount;
        
        for(int i = 0; i < genCount; i++)
        {
            string key = GameManager._instance.Get_Random_Inactive();
            GameManager._instance.Gen_Monster(key);
        }


        if (rest > 0)
        {
            return rest;
        }
        else
        {
            return 0;
        }
    }

    
}
