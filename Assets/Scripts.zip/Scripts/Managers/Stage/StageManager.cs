using UnityEngine;
using System;
using System.Collections.Generic;
public class StageManager 
{
    StageBase stage;
    Defines.StageType stageType;
    [SerializeField]int monster_GenCount = 7; //�ѹ��� �� �Ǵ� �ִ� ���� �� 
    List<StageField> stageFields = new List<StageField>();
    public void SetStage(Defines.StageType type)
    {
        SetStageType(type);
        ChangeStage();
    }

    void SetStageType(Defines.StageType type)
    {
        stageType = type;
    }

    public int Get_Once_MonsterGenCount()
    {
        return monster_GenCount;
    }
    public List<StageField> Get_StageList()
    {
        return stageFields;
    }
    public void Add_Stage_List(StageField stage)
    {
        if (!stageFields.Contains(stage))
        {
            stageFields.Add(stage);
        }
    }
    public void ChangeStage()
    {
        switch (stageType)
        {
            case Defines.StageType.Infinity:
                stage = new Stage_Infinity();
                break;
            case Defines.StageType.KillCount:
                stage = new Stage_KillCount();
                break;
            case Defines.StageType.Boss:
                stage = new Stage_Boss();
                break;
            default:
                Debug.Log("StageType Error");
                break;
        }
    }

}
