using UnityEngine;
using System;
using System.Collections.Generic;
public class Stage_ClearReward : MonoBehaviour
{
    string id;
    string id_Group;
    string id_Item;
    int quantity;
}
